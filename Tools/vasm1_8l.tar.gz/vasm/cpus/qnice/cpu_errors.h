  "illegal operand",ERROR,
  "word register expected",ERROR,
  "",ERROR,
  "value does not find in %d bits",WARNING,
  "data size not supported",ERROR,

