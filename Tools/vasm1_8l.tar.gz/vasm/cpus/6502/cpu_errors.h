  "instruction not supported on selected architecture",ERROR,
  "trailing garbage in operand",WARNING,
  "missing closing parenthesis in addressing mode",ERROR,
  "data size %d not supported",ERROR,
  "relocation does not allow hi/lo modifier",ERROR,
  "operand doesn't fit into %d bits",ERROR,                           /* 05 */
  "branch destination out of range",ERROR,
  "illegal bit number",ERROR,
  "identifier expected",ERROR,
  "multiple hi/lo modifiers",WARNING,
  "zero/direct-page addressing not available",ERROR,                  /* 10 */
  "operand not in zero/direct-page range",ERROR,
  "signed addend doesn't fit into %d bits",WARNING,
  "missing closing square-bracket in addressing mode",ERROR,
